<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/*
 *	@author : Venance Edson
 *  @support: support@codeslab.net
 *	date	: dec, 2016
 *	TemboPos
 *	http://www.xchangewallet.com
 *  version: 1.0
 */

class Settings_Model extends MY_Model
{
    public $_table_name;
    public $_order_by;
    public $_primary_key;


}