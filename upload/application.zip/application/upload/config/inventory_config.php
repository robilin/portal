<?php

$config['site_name'] = 'Inventory Management';
